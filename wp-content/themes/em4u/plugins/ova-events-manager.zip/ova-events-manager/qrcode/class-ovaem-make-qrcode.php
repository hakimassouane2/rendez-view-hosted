<?php 
defined( 'ABSPATH' ) || exit();

require( OVAEM_PLUGIN_PATH.'/qrcode/qrcode.class.php' );



