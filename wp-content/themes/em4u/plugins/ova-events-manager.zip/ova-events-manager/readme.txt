Requires at least: 4.6
Tested up to: 4.9