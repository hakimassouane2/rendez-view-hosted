<?php if ( !defined( 'ABSPATH' ) ) exit();
//get_header( ); ?>
<div class="container ova-page-section">
	<div class="result_ticket">

		<?php // Check Permission 
		$qr = isset( $_REQUEST['qr'] ) ? esc_html( $_REQUEST['qr'] ) : '';
		$qrcode = isset( $_REQUEST['qrcode'] ) ? esc_html( $_REQUEST['qrcode'] ) : '';
		$prefix = OVAEM_Settings::prefix();
		
		if( $qr ){

			$check = apply_filters( 'ovaem_check_ticket', $qr );
			if( $check ){ ?>

				<strong>
					<?php echo esc_html__('Ticket is valid', 'ovaem-events-manager'); ?> <br/>
				</strong>

				<?php if( $check->have_posts() ): while( $check->have_posts() ): $check->the_post() ?>
					<label>
						<?php esc_html_e('Ticket ID', 'ovaem-events-manager'); ?>:
					</label>&nbsp;<?php echo get_the_title(); ?><br/>

					<label>
						<?php esc_html_e('Name', 'ovaem-events-manager'); ?>:
					</label>&nbsp;<?php echo get_post_meta( get_the_id(), $prefix.'_name', true); ?><br/>
					<label>
						<?php esc_html_e('Number Ticket', 'ovaem-events-manager'); ?>:
					</label>&nbsp;<?php echo get_post_meta( get_the_id(), $prefix.'_number' , true); ?><br/>

					<label>
						<?php esc_html_e('Phone', 'ovaem-events-manager'); ?>:
					</label>&nbsp;<?php echo get_post_meta( get_the_id(), $prefix.'_phone', true); ?><br/>

					<label>
						<?php esc_html_e('Email', 'ovaem-events-manager'); ?>:
					</label>&nbsp;<?php echo get_post_meta( get_the_id(), $prefix.'_email', true); ?><br/>

					<label>
						<?php esc_html_e('Address', 'ovaem-events-manager'); ?>:
					</label>&nbsp;<?php echo get_post_meta( get_the_id(), $prefix.'_address', true); ?><br/>

					<label>
						<?php esc_html_e('Description', 'ovaem-events-manager'); ?>:
					</label>&nbsp;<?php echo get_post_meta( get_the_id(), $prefix.'_desc', true); ?><br/>
					
				<?php endwhile; endif; wp_reset_postdata(); ?>
				
			<?php }else{ ?>
				
					<?php echo esc_html__('Ticket is invalid', 'ovaem-events-manager'); ?>
				
			<?php }
			
		}else{


			$buyer[''] = get_post_meta( get_the_id(), 'ovaem_ticket_code', true );
			$buyer[''] = get_post_meta( get_the_id(), 'ovaem_ticket_event_name', true );
			$buyer[''] = get_post_meta( get_the_id(), 'ovaem_ticket_event_package', true );
			$buyer[''] = get_post_meta( get_the_id(), 'ovaem_ticket_event_start_time', true );
			$buyer[''] = get_post_meta( get_the_id(), 'ovaem_ticket_event_end_time', true );
			$buyer[''] = get_post_meta( get_the_id(), 'ovaem_ticket_event_venue', true );
			$buyer[''] = get_post_meta( get_the_id(), 'ovaem_ticket_event_address', true );
			$buyer[''] = get_post_meta( get_the_id(), 'ovaem_ticket_from_order_id', true );




			$result = apply_filters( 'ovame_check_qrcode_ticket', $qrcode );
			if( $result != '' ) { ?>
				
					<h1 style="color: blue;"><?php esc_html_e( 'Valid', 'ovaem-events-manager' ); ?></h1>

					

					<label>
						<strong style="min-width: 90px;display: inline-block ;"><?php esc_html_e( "Name",  "ovaem-events-manager" ); ?>:</strong>
						<?php echo $result['name']; ?>
					</label><br>

					<label>
						<strong style="min-width: 90px;display: inline-block ;"><?php esc_html_e( "Code",  "ovaem-events-manager" ); ?>:</strong>
						<?php echo $result['code']; ?>
					</label><br>

					<label>
						<strong style="min-width: 90px;display: inline-block ;"><?php esc_html_e( "Event",  "ovaem-events-manager" ); ?>:</strong>
						<?php echo $result['event']; ?>
					</label><br>

					<label>
						<strong style="min-width: 90px;display: inline-block ;"><?php esc_html_e( "Order ID",  "ovaem-events-manager" ); ?>:</strong>
						<?php echo $result['orderid']; ?>
					</label><br>

					<label>
						<strong style="min-width: 90px;display: inline-block ;"><?php esc_html_e( "Package",  "ovaem-events-manager" ); ?>:</strong>
						<?php echo $result['package']; ?>
					</label><br>

					<label>
						<strong style="min-width: 90px;display: inline-block ;"><?php esc_html_e( "Start time",  "ovaem-events-manager" ); ?>:</strong>
						<?php echo $result['start_time']; ?>
					</label><br>

					<label>
						<strong style="min-width: 90px;display: inline-block ;"><?php esc_html_e( "End time",  "ovaem-events-manager" ); ?>:</strong>
						<?php echo $result['end_time']; ?>
					</label><br>

					<label>
						<strong style="min-width: 90px;display: inline-block ;"><?php esc_html_e( "Venue",  "ovaem-events-manager" ); ?>:</strong>
						<?php echo $result['venue']; ?>
					</label><br>

					<label>
						<strong style="min-width: 90px;display: inline-block ;"><?php esc_html_e( "Address",  "ovaem-events-manager" ); ?>:</strong>
						<?php echo $result['address']; ?>
					</label><br>

					<label>
						<strong style="min-width: 90px;display: inline-block ;"><?php esc_html_e( "Email",  "ovaem-events-manager" ); ?>:</strong>
						<?php echo $result['email']; ?>
					</label><br>
					<label>
						<strong style="min-width: 90px;display: inline-block ;"><?php esc_html_e( "Phone",  "ovaem-events-manager" ); ?>:</strong>
						<?php echo $result['phone']; ?>
					</label><br>
					<label>
						<strong style="min-width: 90px;display: inline-block ;"><?php esc_html_e( "Address",  "ovaem-events-manager" ); ?>:</strong>
						<?php echo $result['address']; ?>
					</label><br>
					<label>
						<strong style="min-width: 90px;display: inline-block ;"><?php esc_html_e( "Company",  "ovaem-events-manager" ); ?>:</strong>
						<?php echo $result['company']; ?>
					</label><br>
					<label>
						<strong style="min-width: 90px;display: inline-block ;"><?php esc_html_e( "Description",  "ovaem-events-manager" ); ?>:</strong>
						<?php echo $result['desc']; ?>
					</label><br>

				
			<?php }else{ ?>
				<h1 style="color: red;"><?php esc_html_e( 'InValid', 'ovaem-events-manager' ); ?></h1>
				<?php esc_html_e( "The Ticket isn't verify OR checked in ago ", 'ovaem-events-manager' ); ?>
			<?php }
		}
		?>

	</div>
</div>

<?php //get_footer( );
