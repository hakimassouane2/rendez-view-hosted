<?php if ( !defined( 'ABSPATH' ) ) exit();
	get_header( );
?>
	<?php esc_html_e( "Error Send Mail", "ovaem-events-manager" ); ?>
	<a href="#" onclick="window.history.go(-1); return false;" ><?php esc_html_e( "Go Back", "ovaem-events-manager" ); ?></a>


<?php get_footer( );
